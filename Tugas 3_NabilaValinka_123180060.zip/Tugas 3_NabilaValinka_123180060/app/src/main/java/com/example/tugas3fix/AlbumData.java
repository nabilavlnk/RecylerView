package com.example.tugas3fix;

import java.util.ArrayList;

public class AlbumData {
    private static String[] albumTitles = {
            "Persona",
            "asd;ofboabs"
    };

    private static String[] albumDesc = {
            "2020",
            "2015"
    };

    static ArrayList<Album> getlistData() {
        ArrayList<Album> list = new ArrayList<>();

        for (int position = 0; position < albumTitles.length; position++){
            Album album = new Album();
            album.setsName(albumTitles[position]);
            album.setsDetail((albumDesc[position]));
            list.add(album);
        }
        return list;
    }
}
