package com.example.tugas3fix;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Album> album = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView =findViewById(R.id.rv_album);
        recyclerView.setHasFixedSize(true);

        album.addAll(AlbumData.getlistData());
        showRecyclerView();

        recyclerView.setOnClickListener(this::onClick);
    }

    private void showRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        AlbumAdapter listHeroAdapter = new AlbumAdapter(album);
        recyclerView.setAdapter(listHeroAdapter);
    }

    private void onClick(View v) {
        Intent moveWithDataIntent = new Intent(MainActivity.this, Activity_detail.class);
        moveWithDataIntent.putExtra("umur", 20);
        moveWithDataIntent.putExtra("nama", "Bayu Saputra");
        startActivity(moveWithDataIntent);
    }
}