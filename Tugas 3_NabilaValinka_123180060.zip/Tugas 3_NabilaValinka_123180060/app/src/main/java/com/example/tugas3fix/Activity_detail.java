package com.example.tugas3fix;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Activity_detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail2);

        TextView tvTerimaData;

        setContentView(R.layout.activity_detail2);
        tvTerimaData = findViewById(R.id.tv_terima_data);
        String nama = getIntent().getStringExtra("nama");
        int umur = getIntent().getIntExtra("umur", 0);
        String text = "Nama kita " + nama + ", Umur kita " + umur;
        tvTerimaData.setText(text);
    }
    }